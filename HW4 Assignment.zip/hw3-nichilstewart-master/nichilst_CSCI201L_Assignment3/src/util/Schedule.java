package util;

import java.io.Serializable;
import java.util.Vector;

public class Schedule implements Serializable{
    	
	private Vector<Vector<Task>> taskList;
    
    public Schedule() {
        taskList = new Vector<Vector<Task>>();
    }

    public void addTask(int time, String restaurant, String food) {
    	if (taskList.size() > 0) {	
    		Vector<Task> get_t = new Vector<Task>();
    		get_t = taskList.get((taskList.size()-1));
    		int temp_time = get_t.get(0).getTime();  		
    		if (time == temp_time) {
    			get_t.add(new Task(time, restaurant, food));   			
            	return;
    		}
    	}
		Task temp_t = new Task(time, restaurant, food);
		Vector<Task> t = new Vector<Task>();
		t.add(temp_t);
		taskList.add(t);
    }

    public Vector<Vector<Task>> getTaskList() {
        return taskList;
    }
    
    // Inner class to store task object
    public class Task implements Serializable{
        private int time;
        private String restaurant;
        private String food;
		private double latitude;
        private double longitude;
        
        public Task(int time, String restaurant, String food) {
            this.time = time;
            this.restaurant = restaurant;
            this.food = food;
        }

        public int getTime() {
            return time;
        }

        public String getRestaurant() {
            return restaurant;
        }

        public String getFood() {
            return food;
        }
        public double getLatitude() {
        	return latitude;
        }
        public void setLatitude(double latitude) {
        	this.latitude = latitude;
        }
        public double getLongitude() {
        	return longitude;
        }
        public void setLongitude(double longitude) {
        	this.longitude = longitude;
        }
        
    }
}