package util;

import java.util.ArrayList;
import java.util.Set;

public class Restaurant {
    private String name;
    private String address;
    private Double latitude;
    private Double longitude;
    private Set<String> categories;
    private Integer drivers;
    private ArrayList<String> menu;
    private transient double distance;

    public Restaurant(String name, String address, Double latitude, Double longitude, Integer drivers,
                      Double distance, ArrayList<String> menu) {
        this.name = name;
        this.address = address;
        this.latitude = latitude;
        this.longitude = longitude;
        this.menu = menu;
        this.drivers = drivers;
        this.distance = -1; // Default to -1
    }
    
    public Restaurant() {
    	
    }

    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public Double getLatitude() {
        return latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public ArrayList<String> getMenu() {
        return menu;
    }

    public Integer getDrivers() {
        return drivers;
    }

    public double getDistance() {
        return distance;
    }

    /**
     * Checks if any field in this object is null
     * @return true if any field is null
     */
    public boolean isComplete() {
        // Checks if any fields are null and returns the opposite value
        // This could be re-written with the "not" distributed in but that's a lot of unnecessary work
        return !(this.name == null || this.address == null || this.latitude == null || this.longitude == null
                || this.menu == null || this.drivers == null);
    }

    /**
     * Calculates and sets distance from user to this restaurant
     *
     * @param latitude Latitude of user
     * @param longitude Longitude of user
     */
    public void setDistance(double latitude, double longitude) {
        this.distance = 3963.0 * Math.acos((Math.sin(Math.toRadians(latitude)) * Math.sin(Math.toRadians(this.latitude)))
                + Math.cos(Math.toRadians(latitude)) * Math.cos(Math.toRadians(this.latitude))
                * Math.cos(Math.toRadians(longitude) - Math.toRadians(this.longitude)));
    }
    
    public void setDistance(double distance) {
        this.distance = distance;
    }

	public void setLatitude(double latitude) {
		this.latitude = latitude;		
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

    public Set<String> getCategories() {
        return categories;
    }

    public void setCategories(Set<String> categories) {
        this.categories = categories;
    }
	
}
