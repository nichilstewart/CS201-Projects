package util;

import java.io.Serializable;

public class Message<T> implements Serializable {
	public static final long serialVersionUID = 1;
	private String type;
	private T message;
	
	// 5 types in total!
	
	// FROM SERVER TO CLIENT:
	//Types include: coordinateSet, currentDrivers, orderVector, completionNotice
	//				 Vector<Double>       int      Vector<Task>      String
	
	// FROM CLIENT TO SERVER:
	// notBusy notice (so client can send back a new orderVector)
		
	public Message(String type, T message) {
		this.type = type;
		this.message = message;
	}
	public String getType() {
		return type;
	}
	
	public T getMessage() {
		return message;
	}
}
