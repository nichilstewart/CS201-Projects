package util;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.google.gson.JsonParseException;

public class YelpClient {
    private static final String HOST = "https://api.yelp.com";
    private static final String ENDPOINT = "/v3/businesses/search";
    private static final String CLIENT_ID = "DL4mIv7TioZWkKatmOoKRA";
    private static final String API_KEY = "lN5f9RyShhp3Mvz7RpkJMPKk7E6CXcWI_XoFnW51mgIRYh_SojdCkGn7w4H2YR4PDEV1vYPrtRE_YoGaQ2Z3wwhoXZHCp1TNPeXELQ2HIlHKE_HzC0919T10UkmAXnYx";
	private static final int SEARCH_LIMIT = 2;
	
    public List<Restaurant> search(float lat, float lon, String term){
    	
        term = term.replace(' ', '_'); 
        term = term.replace('\'', '_'); 
        term = term.replace('�', '_'); 
        
    	String query = String.format("latitude=%s&longitude=%s&term=%s&categories=%s&radius=%s&limit=%s",lat, lon, term, "Restaurant", 40000, SEARCH_LIMIT);

    	String url = HOST + ENDPOINT + "?" + query;
        StringBuilder responseBody = new StringBuilder();
        try{
            HttpURLConnection connection = (HttpURLConnection)new URL(url).openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Authorization", "Bearer "+API_KEY);

            int responseCode = connection.getResponseCode(); //send request
            if(responseCode != 200) {
                return new ArrayList<>();
            }
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line = "";
            while((line = reader.readLine()) != null) {
                responseBody.append(line);
            }
            reader.close();

        }catch (Exception e){
            e.printStackTrace();
        }

        try{
            JSONObject businesses = new JSONObject(responseBody.toString());
            return getRestaurantList(businesses.getJSONArray("businesses"));
        } catch(JSONException e) {
            e.printStackTrace();
        }

        return new ArrayList<>();
    }

    //Updates the longitude and latitude of all restaurants in array
    public List<Restaurant> getRestaurantList(JSONArray restaurants) throws JSONException{
        List<Restaurant> list = new ArrayList<>();
        for(int i = 0; i < restaurants.length(); i++){
            JSONObject restaurantObj = restaurants.getJSONObject(i);
            Restaurant restaurant = new Restaurant();
            
            if (!restaurantObj.isNull("name")) {
                restaurant.setName(restaurantObj.getString("name"));
            }
           
			JSONObject coordinates = (JSONObject)restaurantObj.get("coordinates");
			
			if (!restaurantObj.isNull("coordinates")) {
				restaurant.setLatitude(coordinates.getDouble("latitude"));
				restaurant.setLongitude(coordinates.getDouble("longitude"));
			}
            
            restaurant.setCategories(getCategories(restaurantObj));
            list.add(restaurant);
        }
        return list;
    }   

    public static Set<String> getCategories(JSONObject restaurantObj) throws JSONException{
        Set<String> categories = new HashSet<>();
        if (!restaurantObj.isNull("categories")) {
            JSONArray classifications = restaurantObj.getJSONArray("categories");
            for (int i = 0; i < classifications.length(); ++i) {
                JSONObject classification = classifications.getJSONObject(i);
                if (!classification.isNull("alias")) {
                    categories.add(classification.getString("alias"));
                }
            }
        }
        return categories;
    }  
}