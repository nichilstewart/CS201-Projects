package util;

public class FieldNotFoundException extends Exception {
    public FieldNotFoundException(String message) {
        super(message);
    }
}
