import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.SocketException;
import java.util.Scanner;
import java.util.Vector;

import util.Message;
import util.TimestampUtil;
import util.Schedule.Task;

public class ServerThread extends Thread {

	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	private static DriverServer cr;
	public boolean isDriving = false;	
	public boolean noMoreOrders = false;
	public boolean completeAllOrders = false;	
	private double userLatitude;
	private double userLongitude;
	private double hqLatitude;
	private double hqLongitude;
	
	public ServerThread(Socket s, DriverServer cr) {
		try {
			this.cr = cr;
			oos = new ObjectOutputStream(s.getOutputStream());
			ois = new ObjectInputStream(s.getInputStream());					
		} catch (IOException ioe) {
			System.out.println("ioe in ServerThread constructor: " + ioe.getMessage());
		}
	}
	
	public void setLoc(Task t) {
		this.userLatitude = t.getLatitude();
		this.userLongitude = t.getLongitude();
	}

	public double calcDist(Task t) { //calculate distance from current location
		double latitude = t.getLatitude();
		double longitude = t.getLongitude();	
		return 3963.0 * Math.acos((Math.sin(Math.toRadians(userLatitude)) * Math.sin(Math.toRadians(latitude))) + Math.cos(Math.toRadians(userLatitude))
        * Math.cos(Math.toRadians(latitude)) * Math.cos(Math.toRadians(userLongitude) - Math.toRadians(longitude)));
	}
	
	public double calcHQDist() { //calculate distance from HQ
        return 3963.0 * Math.acos((Math.sin(Math.toRadians(hqLatitude)) * Math.sin(Math.toRadians(userLatitude)))
                + Math.cos(Math.toRadians(hqLatitude)) * Math.cos(Math.toRadians(userLatitude))
                * Math.cos(Math.toRadians(hqLongitude) - Math.toRadians(userLongitude)));
	}
		
	public double timeClosest(Vector<Task> tasks) {	//get time to closest delivery + remove task
		Task min = tasks.get(0);
		for(Task t : tasks) {
			if (calcDist(t) < calcDist(min)) {
				min = t;
			}
		}
		double val = calcDist(min);
		this.userLatitude = min.getLatitude();
		this.userLongitude = min.getLongitude();
		tasks.remove(min); 
		return val;	
	}
	
	public Task findClosest(Vector<Task> tasks) { //get the closest task object
		Task min = tasks.get(0);
		for(Task t : tasks) {
			if (calcDist(t) < calcDist(min)) {
				min = t;
			}
		}
		return min;	
	}
		
	public void sendOrder(Message cm) throws InterruptedException {
		try {
			oos.writeObject(cm);
			oos.flush();
		} catch (IOException ioe) {
			System.out.println("ioe: " + ioe.getMessage());
		}
	}
	
	public void sendMessage(Message cm) throws InterruptedException {
		try {			
			if (cm.getType().equals("orderVector")) { //received delivery order	
				try {
					this.isDriving = true;
					Vector<Task> orders = new Vector<Task>();
					orders = (Vector<Task>) cm.getMessage();					
					oos.writeObject(new Message("returnMe", orders));
					oos.flush(); //send for client	
				} finally {
					//this.isDriving = false; 
				}
			}
			else if (cm.getType().equals("currentDrivers")) { //received driver count			
				oos.writeObject(cm);
				oos.flush();				
			}
			else if (cm.getType().equals("coordinateSet")) { //received coordinates
				Vector<Double> t = new Vector<Double>();
				t = (Vector<Double>) cm.getMessage();			
				this.userLatitude = t.elementAt(0);
				this.userLongitude = t.elementAt(1);	
				this.hqLatitude = t.elementAt(0);
				this.hqLongitude = t.elementAt(1);
				this.start();					
				oos.writeObject(cm);
				oos.flush();
			}
			else if (cm.getType().equals("finishNotice")) { //no more orders
				this.noMoreOrders = true;
			}
			else if (cm.getType().equals("compNotice")) { //all deliveries complete
				oos.writeObject(cm);
				oos.flush();
				this.completeAllOrders = true;
			}	
		} catch (IOException ioe) {
			System.out.println("ioe: " + ioe.getMessage());
		}
	}
	
	public void run() {	
		while (true) {	
			try {				
				if(completeAllOrders == true) {
					break;
				}
				Message cm = (Message)ois.readObject(); 
				String type = cm.getType();
				
				if (cm.getType().equals("returnMe")) {	//get directed task objects
					this.isDriving = true;					
					Vector<Task> orders = new Vector<Task>();
					orders = (Vector<Task>) cm.getMessage();
					boolean first = true;
					for(Task t : orders) {
						String startString = "[" + TimestampUtil.getTimestamp() + "] Starting delivery of " + t.getFood() + " to " + t.getRestaurant() + ".";
						oos.writeObject(new Message("jobStatus", startString));
						oos.flush();
					}
					oos.writeObject(new Message("jobStatus", ""));
					oos.flush();
					
					while(true) {										
						if (orders.size() == 0) { //must drive back to HQ
							String output = "[" + TimestampUtil.getTimestamp() + "] Finished all deliveries, returning back to HQ.";
							oos.writeObject(new Message("jobStatus", output));
							oos.flush();
							
							Thread.sleep((long)(calcHQDist())*1000);
							output = "[" + TimestampUtil.getTimestamp() + "] Returned to HQ.\n";
							oos.writeObject(new Message("jobStatus", output));
							oos.flush();
							
							this.userLatitude = this.hqLatitude;
							this.userLongitude = this.hqLongitude;	
							if (noMoreOrders == true) {
								completeAllOrders = true;
							}
							cr.updateJob();	
							this.isDriving = false;
							break;
						}
						Task next = findClosest(orders);
						double time = timeClosest(orders);
						if (time != 0 && !first) { //continuing delivery
							String output = "\n[" + TimestampUtil.getTimestamp() + "] Continuing delivery to "+ next.getRestaurant() + ".\n";
							oos.writeObject(new Message("jobStatus", output));
							oos.flush();
						}
						Thread.sleep((long)(time*1000));
						String output = "[" + TimestampUtil.getTimestamp() + "] Finished delivery of " + next.getFood() + " to " + next.getRestaurant() + ".";
						oos.writeObject(new Message("jobStatus", output));
						oos.flush();
						first = false;
					}
				}
			} catch (SocketException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (ClassCastException e) {
				e.printStackTrace();
			}
			finally {
				this.isDriving = false;
			}
		}
	}
}

