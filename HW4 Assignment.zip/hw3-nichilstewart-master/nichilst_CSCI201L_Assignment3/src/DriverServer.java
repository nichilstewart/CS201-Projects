import com.google.gson.JsonSyntaxException;

import util.FieldNotFoundException;
import util.Message;
import util.Restaurant;
import util.Schedule;
import util.Schedule.Task;
import util.ScheduleFormatException;
import util.ScheduleParser;
import util.TimestampUtil;
import util.YelpClient;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Vector;
import java.util.concurrent.Semaphore;

public class DriverServer {
    private static Scanner scan;
    private static Schedule schedule;
    private static double userLatitude;
    private static double userLongitude;
    private static int port = 3456;
    private static int currDrivers;
    private static int totalDrivers;
	private static Semaphore numConcurrentConnections;
	private static Vector<ServerThread> serverThreads = new Vector<ServerThread>();
	private static Vector<Vector<Task>> orderQueue = new Vector<Vector<Task>>();
	private static int totalJobs;
	private static Vector<Integer> jobsComplete = new Vector<Integer>();
	
    public static void main(String[] args) throws InterruptedException {
        scan = new Scanner(System.in);
        loadScheduleFile(); //load schedules
        getUserLocation(); //get user location
        getTotalDrivers(); //get total drivers
        getYelpData(); //load yelp data
        DriverServer ds = new DriverServer(); //construct server + get connections
        
        //Start main driving program
        totalJobs = schedule.getTaskList().size();
        long startTime = System.currentTimeMillis(); //set timers
        long elapsedTime = 0;        
        while (!schedule.getTaskList().isEmpty() || !orderQueue.isEmpty()) { 
	        if (!schedule.getTaskList().isEmpty()) {
        		if ((elapsedTime / 1000) >= schedule.getTaskList().get(0).get(0).getTime()) {
	        		Vector<Vector<Task>> temp = new Vector<Vector<Task>>();
	        		temp = schedule.getTaskList();
	        		Vector<Task> orders = new Vector<Task>();
	        		orders = temp.get(0);	
	        		orderQueue.add(orders); //load tasks into queue  		        		
	        		temp.remove(0);        		
	        	}
	        }
        	elapsedTime = System.currentTimeMillis() - startTime; //update timer       	   	
        	//if (!orderQueue.isEmpty()) {
        	while (!orderQueue.isEmpty()) {
        		Vector<Task> t = new Vector<Task>();
        		t = orderQueue.get(0);
        	
	        	for (ServerThread st : serverThreads) {	
	        		if (st.isDriving == false) { //find a waiting driver	        			
	        			Message out = new Message("orderVector", t);
	        			st.sendMessage(out);
						orderQueue.remove(0);
	        			break;
	        		}
	        	}
        	}        	
        }             
        String finishString = "No more deliveries";
        for (ServerThread st : serverThreads) {	//let threads know all orders sent out
			Message out = new Message("finishNotice", finishString );
			st.sendMessage(out);
    	}						
		while (true) {
			if (jobsComplete.size() == totalJobs) {
				break;
			}			
		}        			
        String compString = "[" + TimestampUtil.getTimestamp() + "] All orders completed!";
		Message comp = new Message("compNotice", compString );
		for (ServerThread st : serverThreads) {	//let threads know all orders have been delivered
    		st.sendMessage(comp);
    	}     
        System.out.println("All orders completed!"); //update server
        scan.close();
        System.exit(0);
    }
    
    public void updateJob() {
    	jobsComplete.add(1);
    }
        
    private static void loadScheduleFile() {
        while(true){
            System.out.println("What is the name of the schedule file?");
            String fileName = scan.nextLine();
            System.out.println();
            try {
                schedule = ScheduleParser.loadSchedule(fileName);
                break;
            } catch (ScheduleFormatException e) {
                System.out.print("That file is not properly formatted. ");
            } catch (IOException e) {
                System.out.print("That file does not exist. ");
            }
        }
    }

    private static void getUserLocation() {
        userLatitude = getLatitude("What is your latitude?");
        userLongitude = getLongitude("What is your longitude?");
    }

    private static double getLatitude(String query) {
        double latitude = 0.0;
        while (true) {
            System.out.println(query);
            String latitudeString = scan.nextLine();
            System.out.println(); // Blank line for spacing
            try {
                latitude = Double.parseDouble(latitudeString);
                if (latitude < -90.0 || latitude > 90.0) {
                	throw new NumberFormatException();
                }
                return latitude;
            } catch (NumberFormatException ignore) { }
        }
    }

    private static double getLongitude(String query) {
        double longitude = 0.0;
        while (true) {
            System.out.println(query);
            String longitudeString = scan.nextLine();
            System.out.println(); // Blank line for spacing
            try {
                longitude = Double.parseDouble(longitudeString);
                if (longitude < -180.0 || longitude > 180.0) {
                	throw new NumberFormatException();
                }
                return longitude;
            } catch (NumberFormatException ignore) { }
        }
    }
    
    private static void getTotalDrivers() {
    	int driverInput = 0;
    	while(true) {
	    	System.out.println("How many drivers will be in service today?");
	        String driverString = scan.nextLine();
	        System.out.println(); // Blank line for spacing
	        try {
	            driverInput = Integer.parseInt(driverString);
	        	if (driverInput < 1) {
	    	    	System.out.print("Please enter a valid number of drivers. ");
	            }
	        	else {
	        		totalDrivers = driverInput;
	        		numConcurrentConnections = new Semaphore(totalDrivers);
	        		return;
	        	}
	        } catch (NumberFormatException ignore) { }
    	}
    }
    
    public DriverServer() throws InterruptedException {
    	try {
			ServerSocket ss = new ServerSocket(port);
			System.out.println("Listening on port " + port + ".\nWaiting for drivers...\n");
			serverThreads = new Vector<ServerThread>();
			this.currDrivers = 0;	        			
			
			while (this.currDrivers < totalDrivers) {
				numConcurrentConnections.acquire();
				Socket s = ss.accept(); // blocking
				System.out.println("Connection from " + s.getInetAddress().getHostAddress());
				if (totalDrivers-currDrivers-1 > 0) {
					System.out.println("Waiting for " + (totalDrivers-currDrivers-1) + " more driver(s)...\n" );
				}
				ServerThread st = new ServerThread(s, this);
				serverThreads.add(st);
				Message m = new Message("currentDrivers", totalDrivers-currDrivers-1);
				for(ServerThread threads : serverThreads) {
					threads.sendMessage(m);
				}
				currDrivers++;
			}
			System.out.println("Starting service.\n");
			Vector<Double> v = new Vector<Double>();
	    	v.add(userLatitude);
	    	v.add(userLongitude);
			Message mmm = new Message("coordinateSet", v); 	
			for(ServerThread threads : serverThreads) {
				threads.sendMessage(mmm);
			}
		} catch (IOException ioe) {
			System.out.println("ioe in ChatRoom constructor: " + ioe.getMessage());
		}
    }		
    
    private static void getYelpData() {  	
    	YelpClient yelpclient = new YelpClient();
		List<Restaurant> mylist = new ArrayList<Restaurant>();   
		int count = 1;
    	
		for (int i=0; i<schedule.getTaskList().size(); i++) {    		
    		Vector<Task> tasks = new Vector<Task>();
    		tasks = schedule.getTaskList().get(i);   		
    		
    		for (int j=0; j<tasks.size(); j++) {    			
    			String input_name = tasks.get(j).getRestaurant();				
    			mylist = yelpclient.search((float)userLatitude,(float)userLongitude,input_name);   			
    			
    			if (mylist.size() > 0) {    	
    	        	tasks.get(j).setLatitude(mylist.get(0).getLatitude());
    	        	tasks.get(j).setLongitude(mylist.get(0).getLongitude());  			
    	        	//System.out.println(count++ + ": " + input_name + " " + mylist.get(0).getLatitude() + " " + mylist.get(0).getLongitude()); //BUGCHECK FIX
    			}   
    		}
    	}  	
	    //System.out.println(); //BUGCHECK FIX
    }
}
