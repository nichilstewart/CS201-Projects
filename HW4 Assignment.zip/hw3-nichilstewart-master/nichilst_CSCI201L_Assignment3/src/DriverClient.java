import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;
import java.util.Vector;
import util.Message;
import util.Schedule.Task;
import util.TimestampUtil;

public class DriverClient{

    private Scanner scan;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	
	public DriverClient() {
		try {
	        scan = new Scanner(System.in);
			System.out.print("Welcome to SalEats v2.0!\nEnter the server hostname: ");
            String hostname = scan.nextLine();
            System.out.print("Enter the server port: ");
            String portString = scan.nextLine();
            int port = Integer.parseInt(portString);
			System.out.print("\n");
            
			Socket s = new Socket(hostname, port);
			ois = new ObjectInputStream(s.getInputStream());
			oos = new ObjectOutputStream(s.getOutputStream());
			
			while(true) {	
				Message cm = (Message)ois.readObject();	//read in messages
				String input = cm.getType();
				
				if (cm.getType().equals("returnMe")) {//redirect to run() method
					oos.writeObject(cm);
					oos.flush();					
				}
				else if (cm.getType().equals("jobStatus")) { //for jobs
					System.out.println(cm.getMessage());
				}
				else if (cm.getType().equals("currentDrivers")) { //get current drivers		
					if (!cm.getMessage().equals(0)) {
						System.out.println(cm.getMessage() + " more driver is needed before the service can begin. Waiting...\n");
					}
				}
				else if (cm.getType().equals("coordinateSet")) { //received coordinates and starting
					System.out.println("All drivers have arrived!\nStarting service.\n");
				}
				else if (cm.getType().equals("compNotice")) { //program completion notice
					System.out.println(cm.getMessage());
					break;
				}	
			}					
		} catch (IOException ioe) {
			System.out.println("Client limit has already been reached.");
		} catch (ClassCastException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} 
	}
	
	public static void main(String [] args) {
		DriverClient cc = new DriverClient();
	}
}