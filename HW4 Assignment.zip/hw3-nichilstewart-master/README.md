## CSCI-201: Assignment 3
#### Authored by: Nichil Stewart - nichilst@usc.edu

#### Program instructions: 
To run this program in Eclipse, first run "DriverServer" to start the server, and then run "DriverClient" 
to add each new client to the server. There is no need to manually run "ServerThread".

#### Additional note:
I added newlines in my client output to match to the sample output in the Assignment 3 description. 
Though the output logic of the newlines within the sample output is sometimes unclear (in order to match
the two client outputs), I tried to copy it as best I could.
