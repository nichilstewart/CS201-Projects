package models;

import java.util.ArrayList;

import models.Restaurant;

//cleaned assignment 1 code
public class RestaurantList {
	private ArrayList<Restaurant> data = new ArrayList<Restaurant>();

	public ArrayList<Restaurant> getData() {
		return data;
	}
	
	//used to check if a requested item has drivers to make the delivery
	public Restaurant searchRestaurants(String name) {
		Restaurant r = null;
        for (Restaurant restaurant: this.data) { //linear search for requested restaurant
            if (restaurant.getName().toLowerCase().equals(name.toLowerCase())) {
            	r = restaurant;
            }
        }
        return r;
    }
}