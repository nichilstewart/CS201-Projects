package models;

import java.util.ArrayList;

public class Restaurant {
	private String name = null;
	private String address = null;
	private Double latitude = null;
	private Double longitude = null;
	private Integer drivers = null;
	private transient Double distance = null; //don't want serialized
	private ArrayList<String> menu = new ArrayList<String>(); 

	//getter and setter functions
	public String getName() {
		return name;
	}

	public String getAddress() {
		return address;
	}

	public Double getLatitude() {
		return latitude;
	}

	public Double getLongitude() {
		return longitude;
	}

	public Integer getDrivers() {
		return drivers;
	}
	
	public void setDrivers(Integer drivers) {
		this.drivers = drivers;
	}

	public Double getDistance() {
		return distance;
	}

	public void setDistance(Double distance) {
		this.distance = distance;
	}
	

	public ArrayList<String> getMenu() {
		return menu;
	}
}