package models;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Driver extends Thread {
	public boolean notBusy;
	private static List<Order> ordersWaiting = Collections.synchronizedList(new ArrayList<Order>());
	private Lock driverLock = new ReentrantLock();
	private Condition availableCondition;
	public static boolean moreOrders = true;

	public Driver() {
		this.notBusy = true;
		availableCondition = driverLock.newCondition();
		this.start();
	}

	public static synchronized void addToWaiting(Order order) {
		ordersWaiting.add(order); //add order to waiting list
	}

	public void accessDriver() {
		try {
			driverLock.lock(); //implement lock
			this.notBusy = false;
			availableCondition.signal();
		} finally {
			driverLock.unlock(); //must unlock
		}
	}

	public void run() { //based on sleeping barbers code
		while(moreOrders) {
			while(!ordersWaiting.isEmpty()) {
				Order order = null;
				synchronized(this) {
					order = ordersWaiting.remove(0); //remove next from list
				}
				order.startingOrder(this); //starting order message
				try {
					Thread.sleep((long)(order.getDistance()*2000)); //(2 trips at 1 second per mile)
				} catch (InterruptedException ie) {
					System.out.println("exception while delivering order" + ie.getMessage());
				}
				order.finishingOrder(this);	//finishing order message
			}						
			try {
				driverLock.lock(); //lock on
				this.notBusy = true;
				availableCondition.await(); //wait signal
			} catch (InterruptedException ie) {
				System.out.println("exception while waiting for order: " + ie.getMessage());
			} finally {
				driverLock.unlock(); //must take lock off
			}
		}
	}
}
