package models;

import java.util.ArrayList;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import util.DateUtil;

public class Order extends Thread {
	private String location;
	private String item;
	private Integer time;
	private Double distance;
	private ArrayList<Driver> drivers;
	private Lock orderLock;
	private Condition deliveringCondition;
	
	public Order(ArrayList<Driver> drivers, OrderData orderdata, Double distance) {
		this.location = orderdata.getLocation();
		this.item = orderdata.getItem();
		this.time = orderdata.getTime();
		this.distance = distance;
		this.drivers = drivers;
		orderLock = new ReentrantLock();
		deliveringCondition = orderLock.newCondition();
	}

	public Double getDistance() {
		return this.distance;
	}

	public void startingOrder(Driver driver) {
		DateUtil.printMessage("Starting delivery of " + item + " from " + location + "!");
	}

	public void finishingOrder(Driver driver) {
		DateUtil.printMessage("Finished delivery of " + item + " from " + location + "!");
		try {
			orderLock.lock(); //set lock
			deliveringCondition.signal();
		} finally {
			orderLock.unlock(); //must release lock
		}
	}

	public void run() {
		try {
			Thread.sleep(this.time * 1000); //sleep until order is ready
		} catch (InterruptedException ie) {
			System.out.println("ie making someone's order" + ie.getMessage());
		}
		
		Driver.addToWaiting(this);
		//get next available driver
		for (int i = 0; i < drivers.size(); ++i) {
			if (drivers.get(i).notBusy == true) {
				drivers.get(i).accessDriver();
				break; //found driver
			}
		}
		
		try {
			orderLock.lock();  //set lock
			deliveringCondition.await(); //wait for signal
		} catch (InterruptedException ie) {
			System.out.println("ie delivering order: " + ie.getMessage());
		} finally {
			orderLock.unlock(); //must release lock
		}
	}
}
