package models;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RestaurantThread extends Thread {
	private Restaurant restaurant;
	private Integer drivers;
	private ArrayList<OrderData> ordersData;
	
	public RestaurantThread(Restaurant restaurant, ArrayList<OrderData> orderdata) {
		this.restaurant = restaurant;
		this.drivers = restaurant.getDrivers();
		this.ordersData = getOrderData(orderdata);
	}
	
	private ArrayList<OrderData> getOrderData(ArrayList<OrderData> orderdata) {
		ArrayList<OrderData> data = new ArrayList<OrderData>();
		for (int i = 0; i < orderdata.size(); ++i) {
			if (orderdata.get(i).getLocation().toLowerCase().equals(restaurant.getName().toLowerCase())) {
				data.add(orderdata.get(i)); //if found matching restaurant, add to list
			}
		}
		return data;
	}	
	
	public void run() {
		ArrayList<Driver> allDrivers = new ArrayList<Driver>();
		
		for (int i = 0; i < drivers; ++i) { //add # of drivers to list
			allDrivers.add(new Driver());
		}
		ExecutorService executors = Executors.newCachedThreadPool();
		for (int i = 0; i < ordersData.size(); ++i) { //execute each of the orders
			Order order = new Order(allDrivers, ordersData.get(i), restaurant.getDistance());
			executors.execute(order);
		}
		executors.shutdown(); //shutdown then check if threads are finished
		while(!executors.isTerminated()) {
			Thread.yield(); //work-efficient for JVM
		}
		for (int i = 0; i < drivers; ++i) {//access all drivers
			allDrivers.get(i).accessDriver();
		}
	}
}
