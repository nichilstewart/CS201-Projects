import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;

import models.Driver;
import models.OrderData;
import models.Restaurant;
import models.RestaurantList;
import models.RestaurantThread;
import util.DriverCountException;
import util.FieldNotFoundException;

public class Main {
	private static Gson gson = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
	private static Scanner scanner = new Scanner(System.in);
	private static String fileName;
	private static RestaurantList restaurants;
	private static double userLatitude;
	private static double userLongitude;
	private static ArrayList<OrderData> ordersData  = new ArrayList<OrderData>(); 
	
	public static void main(String[] args) {
		loadRestaurantFile(); //load restaurant file
		loadScheduleFile(); //load scheduling file
		getUserLocation(); //get longitude/latitude
		loadDistances(); //load distances from restaurants
		
		ExecutorService executor = Executors.newCachedThreadPool();
		System.out.println("Starting execution of program...");
		for (int i = 0; i < restaurants.getData().size(); ++i) { //execute restaurant threads
			RestaurantThread r = new RestaurantThread(restaurants.getData().get(i), ordersData);
			executor.execute(r);
		}
		executor.shutdown();
		while (!executor.isTerminated()) {
			Thread.yield(); //efficient JVM management
		}
		System.out.println("All orders complete!");
		Driver.moreOrders = false; //set boolean to finish
		System.exit(0); //exit program
	}
	
	private static void loadRestaurantFile() { //gets/checks restaurant data
		boolean validFile = false;
		
		do { //repeats until valid
			System.out.print("What is the name of the file containing the restaurant information? ");
			fileName = scanner.nextLine();
			System.out.println();

			try { //parse json data using gson
            	gson = new Gson();
            	restaurants = gson.fromJson(new FileReader(fileName), RestaurantList.class);
            	validateVariables();
                validFile = true;
            } catch (FileNotFoundException e) { //no file found
                System.out.println("The file " + fileName + " could not be found.\n");
            } catch (NullPointerException e) { //file is empty
				System.out.println("The file " + fileName + " is empty.\n");
            } catch (FieldNotFoundException e) { //file is missing data
                System.out.println("Missing data parameters.\n");
            } catch (ClassCastException | JsonSyntaxException e){ //parse errors exist
                System.out.println("Data is malformed.\n");
            }
		} while (!validFile);
	}
	
	//check for missing data, imported from assignment 1 code
	private static void validateVariables() throws FieldNotFoundException {
		for (int i = 0; i < restaurants.getData().size(); ++i) {
			Restaurant validator = restaurants.getData().get(i);
			if (validator.getName() == null || validator.getAddress() == null || validator.getLatitude() == null || 
				validator.getLongitude() == null || validator.getDrivers() == null || validator.getMenu() == null) {
				throw new FieldNotFoundException("Missing data parameters."); //added getDrivers() check
			}
		}
	}

	private static void loadScheduleFile() {
		boolean validFile = false;
		do {
			System.out.print("What is the name of the file containing the schedule information? ");
			fileName = scanner.nextLine();
			System.out.println();

            BufferedReader br = null;
            try { //parse file
            	br = new BufferedReader(new FileReader(fileName));
            	String str;
            	while ((str = br.readLine()) != null) {
            		OrderData orderdata = new OrderData();
            		String[] parser = str.split(", "); //splits string after comma
            		orderdata.setTime(Integer.parseInt(parser[0])); //get time integer
            		orderdata.setLocation(parser[1]); //get location string
            		orderdata.setItem(parser[2]); //get item string
            		
            		if (!driversExist(parser[1])) { //if there are no drivers that can deliver specified item
            			throw new DriverCountException("\nThere are no drivers that can deliver " + parser[2] + ".\n");
            		}
            		ordersData.add(orderdata); //order is valid and can be added
            	}
            	if (ordersData.size() != 0) { //must be orders
                	validFile = true;
            	}
            	else {
            		System.out.println("The file is empty!\n");
            	}
            } catch (FileNotFoundException e) { //file can't be found
                System.out.println("The file " + fileName + " could not be found.\n");
            } catch (NumberFormatException e) { //file has format issues
                System.out.println("The file's data is malformed.\n");
            } catch (ArrayIndexOutOfBoundsException e) { //missing data
            	System.out.println("The file's missing some data parameters for at least one order.\n");
            } catch (IOException e) { //input error
            	System.out.println("The file had an input error!\n");
            } catch (DriverCountException e) { //no drivers to complete order
            	System.out.println(e.getMessage()); //if there are 0 or fewer drivers for a requested item
            } finally {
            	if (br != null) { //reader still has data
            		try {
            			br.close(); //close reader
            		} catch (IOException e) {
            			System.out.println("File could not be closed.");
            		}
            	}
            }
		} while (!validFile);
	}

	//get latitude/longitude, imported from assignment 1 code
    private static void getUserLocation() {
        userLatitude = getLatitude("What is your latitude? ");
        System.out.println(); //spacing
        userLongitude = getLongitude("What is your longitude? ");
        System.out.println(); //spacing
    }
    
	//get latitude/longitude, imported from assignment 1 code
    private static double getLatitude(String query) {
        double latitude = 0.0;
        while (true) {
            System.out.print(query);
            String latitudeString = scanner.nextLine();
            try {
                latitude = Double.parseDouble(latitudeString);
                if (latitude < -90.0 || latitude > 90.0) {
                	throw new NumberFormatException();
                }
                return latitude;
            } catch (NumberFormatException ignore) { }
        }
    }

    private static double getLongitude(String query) {
        double longitude = 0.0;
        while (true) {
            System.out.print(query);
            String longitudeString = scanner.nextLine();
            try {
                longitude = Double.parseDouble(longitudeString);
                if (longitude < -180.0 || longitude > 180.0) {
                	throw new NumberFormatException();
                }
                return longitude;
            } catch (NumberFormatException ignore) { }
        }
    }
    
	//get latitude/longitude, imported from assignment 1 code
    private static void loadDistances() {
    	for (Restaurant r : restaurants.getData()) {
    		r.setDistance(calculateDistance(r.getLatitude(), r.getLongitude()));
    	}
    }
    
	//calculate distance, imported from assignment 1 code
    private static double calculateDistance(double latitude, double longitude) {
    	return 3963.0 * Math.acos((Math.sin(Math.toRadians(userLatitude)) * Math.sin(Math.toRadians(latitude))) + Math.cos(Math.toRadians(userLatitude))
        * Math.cos(Math.toRadians(latitude)) * Math.cos(Math.toRadians(userLongitude) - Math.toRadians(longitude)));
    }
    
	//search restaurant list for restaurant, check if driver count > 0
    private static boolean driversExist(String name) {
    	Restaurant r = restaurants.searchRestaurants(name);
    	if (r.getDrivers() > 0) {
    		return true;
    	}
    	else {//not enough drivers to complete order
    		return false;
    	}
    }
}
