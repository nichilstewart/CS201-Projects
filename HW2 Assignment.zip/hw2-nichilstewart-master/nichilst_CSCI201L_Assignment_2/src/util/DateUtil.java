package util;

import java.util.Calendar;

public class DateUtil {

	public static void printMessage(String message) {
		Calendar cal = Calendar.getInstance();
		String datetime = "[";

		//for digits in minutes < 10
		int hour = cal.get(Calendar.HOUR_OF_DAY);
		if (hour < 10) {datetime += "0" + hour;}
		else {datetime += + hour;}
		
		//for digits in minutes < 10
		int min = cal.get(Calendar.MINUTE);
		if (min < 10) {datetime += ":0" + min;}
		else {datetime += ":" + min;}
		
		//for digits in seconds < 10
		int sec = cal.get(Calendar.SECOND);
		if (sec < 10) {datetime += ":0" + sec;}
		else {datetime += ":" + sec;}
				
		//changed milliseconds to round to 2-digits.
		int mil = cal.get(Calendar.MILLISECOND); //get millisecond digits
		while (mil >= 100) { mil /= 10;} //get to tens place
		if (mil%10 >= 5) {mil = ((mil + 10)/10);} //round up
		else {mil = (mil/10);} //round down
		if (mil == 10) {mil /= 10;} //for 10 case
		
		datetime += "." + mil + "0]";	
		System.out.println(datetime + " " + message);
	}
}