package util;

@SuppressWarnings("serial")
public class FieldNotFoundException extends Exception {
    public FieldNotFoundException(String message) {
        super(message);
    }
}
