package util;

//returns exception if no driver exists to deliver a specific item

@SuppressWarnings("serial")
public class DriverCountException extends Exception {
	public DriverCountException(String message) {
		super(message);
	}

}
