package nichilst_CSCI201L_Assignment1;

import java.util.ArrayList;
import java.util.Comparator;
import java.lang.Math;
import java.math.BigDecimal;
import java.math.RoundingMode; 


public class Restaurant implements java.lang.Comparable<Restaurant>
{

	private String name = ""; //empty entry
	private String address = ""; //empty
	private Double latitude = 200.0; //invalid entry (outside bounds)
	private Double longitude = 200.0; //invalid entry (outside bounds)
	public ArrayList<String> menu = null; //null start

	//restaurant constructor
	public Restaurant(String name, String address, Double latitude, Double longitude, ArrayList<String> menu) 
	{ //initialize values
		this.name = name;
		this.address = address; 
		this.latitude = latitude;
		this.longitude = longitude;
		this.menu = new ArrayList<String>(menu);
	}
	
	//distance calculating function
	public Double calcDist (double lat1, double long1)
	{ //calculates distance between user and restaurant
		double tempLong = (this.longitude - long1);
		Double d = 3963.0 * Math.acos((Math.sin(lat1) * Math.sin(this.latitude)) + 
				   Math.cos(lat1) * Math.cos(this.latitude) * Math.cos(tempLong));
		return d;
	}
	
	public double getDistanceRounded(double lat1, double long1)
	{ //rounds the distance up to tenth's place
		double roundedDist = calcDist(lat1, long1);		
		roundedDist = new BigDecimal(roundedDist).setScale(1, RoundingMode.HALF_UP).doubleValue();
		return roundedDist;
	}
	
	
	public static Comparator<Restaurant> byName()
	{ //compare by name
	    return new Comparator<Restaurant>()
	    {
	        @Override
	        public int compare(Restaurant o1, Restaurant o2)
	        {
	            return o1.getName().compareTo(o2.getName());
	        }
	    };        
	}
	
	public static Comparator<Restaurant> byDist(double lat1, double long1)
	{ //compare by distance
	    return new Comparator<Restaurant>()
	    {
	        @Override
	        public int compare(Restaurant o1, Restaurant o2)
	        {
	            if (o1.calcDist(lat1, long1) - o2.calcDist(lat1, long1) == 0.0)
	            { //if distances are equal
	            	return 0;
	            }
	            else if (o1.calcDist(lat1, long1) - o2.calcDist(lat1, long1) > 0.0)
	            { //if first is longer
	            	return 1;
	            }
	            else
	            { //if second is longer
	            	return -1;
	            }
	        }
	    };        
	}
	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public ArrayList<String> getMenu() {
		return menu;
	}

	public void setMenu(ArrayList<String> menu) {
		this.menu = menu;
	}

	@Override
	public int compareTo(Restaurant arg0) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
