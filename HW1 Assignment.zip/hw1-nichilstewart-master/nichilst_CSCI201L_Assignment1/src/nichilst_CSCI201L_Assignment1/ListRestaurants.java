package nichilst_CSCI201L_Assignment1;

import java.util.ArrayList;

public class ListRestaurants {
	
	private ArrayList<Restaurant> data; 
	
	public ArrayList<Restaurant> getRestaurants() 
	{
		return data;
	}

	public void setRestaurants(ArrayList<Restaurant> restaurants) 
	{
		this.data = restaurants;
	}
	
	public int getSize()
	{
		return data.size();
	}

	public void printRestaurants(double userLat, double userLong)
	{ //prints restaurant information
		String result = "";
		for (int i=0; i < data.size(); i++) {
			result += data.get(i).getName() + ", located " + 
					data.get(i).getDistanceRounded(userLat, userLong) + 
			" miles away at " + data.get(i).getAddress() + "\n";
		}
		System.out.print(result);		
	}
	
	public boolean checkRestaurant(String rest, double userLat, double userLong)
	{ //check if restaurant exists
		boolean found = false;
		for (int i=0; i < data.size(); i++) {		
			if (rest.compareToIgnoreCase(data.get(i).getName()) == 0) {
				found = true; //found restaurant
				System.out.print(data.get(i).getName() + ", located " + 
						data.get(i).getDistanceRounded(userLat, userLong) + 
						" miles away at " + data.get(i).getAddress() + "\n");
				return true;
			}
		}
		if (found == false) {
			System.out.println(rest + " could not be found.\n");
		}
		return false;
	}
	
	public boolean checkItem(String item)
	{ //check if item exists
		System.out.print("\n");
		boolean found = false;
		boolean check = false;
		for (int i=0; i < data.size(); i++) {
			found = false;
			for (int j=0; j < data.get(i).getMenu().size(); j++)
			{
				boolean multiple = false;
				if (data.get(i).getMenu().get(j).toLowerCase().contains(item.toLowerCase()))
				{
					if (found == true) {multiple = true;}
					found = true; //found item
					if (multiple == false) //only 1 matching item
					{
						System.out.print(data.get(i).getName() + " serves " + 
								data.get(i).getMenu().get(j));
					}
					else if (j+1 == data.get(i).getMenu().size()) //last item in list
					{
						System.out.print(" and " + data.get(i).getMenu().get(j)); 
					}
					else //more than 1 matching item
					{
						System.out.print(", " + data.get(i).getMenu().get(j)); 
					}
				}
			}
			if (found == true) { //found info
				System.out.print(".\n");
				check = true;
			}
		}
		if (check == false) {
			System.out.print("No restaurant nearby serves " + item + ".\n\n");
			return false;
		}
		return true;
	}
	
	public boolean nameExists(String name)
	{ //check if name exists
		boolean found = false;
		for (int i=0; i < data.size(); i++) {		
			if (name.compareToIgnoreCase(data.get(i).getName()) == 0) {
				found = true; //found restaurant
				break;
			}
		}
		return found;
	}
	
	public void addRestaurant(String name, String address, Double latitude, Double longitude, ArrayList<String> menu)
	{
		data.add(new Restaurant(name, address, latitude, longitude, menu));
	}
	
	public void removeRestaurant(int index)
	{
		data.remove(index - 1);	
	}
}
