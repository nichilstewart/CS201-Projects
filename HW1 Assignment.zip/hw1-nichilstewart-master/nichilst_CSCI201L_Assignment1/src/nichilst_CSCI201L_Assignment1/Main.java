package nichilst_CSCI201L_Assignment1;

import java.util.*;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;

public class Main {

	//menu printing function
	public static void printOptions(boolean check)
	{
		if (check == false) {return;}
		
		System.out.println("\t1) Display all restaurants");
		System.out.println("\t2) Search for a restaurant");
		System.out.println("\t3) Search for a menu item");
		System.out.println("\t4) Add a new restaurant");
		System.out.println("\t5) Remove a restaurant");
		System.out.println("\t6) Sort restaurants");
		System.out.println("\t7) Exit");
	}
	
	public static Comparator<Restaurant> byName() 
	{ //use comparator to allow multiple fields of searching 
	    return new Comparator<Restaurant>() {
	        @Override
	        public int compare(Restaurant o1, Restaurant o2) {
	            return o1.getName().compareTo(o2.getName());
	        } //returns result of strign comparison
	    };        
	}
	
	public static Comparator<Restaurant> byDist(double lat1, double long1) 
	{ //use comparator to allow multiple fields of searching 
	    return new Comparator<Restaurant>() {
	        @Override
	        public int compare(Restaurant o1, Restaurant o2) {
	            if (o1.calcDist(lat1, long1) - o2.calcDist(lat1, long1) == 0.0) {
	            	return 0; //both distances are equal
	            }
	            else if (o1.calcDist(lat1, long1) - o2.calcDist(lat1, long1) > 0.0) {
	            	return 1; //first is larger
	            }
	            else {
	            	return -1; //second is larger
	            }
	        }
	    };        
	}
		
	//main function 
	public static void main (String [] args)
	{ //build Gson reader for Json-formatted text file 
		Gson gson = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
		ListRestaurants directory = new ListRestaurants();
		Scanner scan = new Scanner(System.in);
		String inputFile = "";
		while(true)
		{ //read in file inputs
			try
			{	
				System.out.print("What is the name of the restaurant file? ");
				inputFile = scan.nextLine(); 
				FileReader fr = new FileReader(inputFile);
				directory = gson.fromJson(fr, ListRestaurants.class);
				
				boolean invalidFile = false;
				for (int i=0; i < directory.getRestaurants().size(); i++) 
				{ //manually check if any entries are left blank
					if((directory.getRestaurants().get(i).getName()).equals("")) {invalidFile = true;}
					if((directory.getRestaurants().get(i).getAddress()).equals("")) {invalidFile = true;}
					if(directory.getRestaurants().get(i).getLatitude() == 200.0) {invalidFile = true;}
					if(directory.getRestaurants().get(i).getLongitude() == 200.0) {invalidFile = true;}
					if(directory.getRestaurants().get(i).getMenu() == null) {invalidFile = true;}
				}
				if (invalidFile == true) {
					System.out.println("The file " + inputFile + " is missing data parameters.\n");
					continue;
				}
				break;
			}
			catch(FileNotFoundException fnfe) //can't locate file location
			{
				System.out.println("The file " + inputFile + " could not be found.\n");
			}
			catch (JsonParseException jpe) //Json couldn't parse the file
			{
				System.out.println("The file " + inputFile + " is not formatted properly.\n");
			}
			catch (java.lang.NullPointerException npe) //data is left blank/missing
			{
				System.out.println("The file " + inputFile + " is missing data parameters.\n");
			}
			catch (java.lang.NumberFormatException nfe) //non-number inputs were entered
			{
				System.out.println("The file " + inputFile + " is not formatted properly.\n");
			}
		}
		System.out.println("The file has been properly read.\n");
		
		double userLat = 0; //set longitude
		double userLong = 0; //set latitude
		while (true) {
			try
			{ //read in latitude 
				System.out.print("What is your latitude? ");
				userLat = Double.parseDouble(scan.nextLine());
				System.out.println();
				break;
			}
			catch(java.lang.NumberFormatException nfe) {
				System.out.println("Please enter a valid numerical input.\n");	
			}
		}
		while (true) {
			try
			{ //read in longitude
				System.out.print("What is your Longitude? ");
				userLong = Double.parseDouble(scan.nextLine());
				System.out.println();
				break;
			}
			catch(java.lang.NumberFormatException nfe) {
				System.out.println("Please enter a valid numerical input.\n");	
			}
		}
		System.out.print("\n");
		
		boolean repeatMenu = true;
		boolean showOptions = true;
		while(repeatMenu) //repeat menu display
		{
			printOptions(showOptions); //showOptions after valid choice
			showOptions = true;
			System.out.print("What would you like to do? ");
			String option = scan.nextLine();
			System.out.println();
			
			if (option.equals("1")) //Display all restaurants
			{
				directory.printRestaurants(userLat, userLong);
			}
			else if (option.equals("2")) //Search for a restaurant
			{
				boolean found = false;
				while (!found) { //continues to ask until restaurant is found
					System.out.print("What is the name of the restaurant you would like to search for? ");
					String restName = scan.nextLine();
					System.out.print("\n");
					found = directory.checkRestaurant(restName, userLat, userLong); //returns true if found
				}
			}
			else if (option.equals("3")) //Search for a menu item
			{
				boolean found = false;
				while (!found) { //continues to ask until item is found
					System.out.print("What menu item would you like to search for? ");
					String itemName = scan.nextLine();
					found = directory.checkItem(itemName); //returns true if found
				}
			}
			else if (option.equals("4")) //Add a new restaurant
			{
				boolean newName = false; //ask for name until unique input
				String restName = ""; //blank
				String restAddr = ""; //blank
				double restLat = 200.0; //outside of acceptable range
				double restLong = 200.0; //outside of acceptable range
				ArrayList<String> restMenu = new ArrayList<String>();
				
				while (!newName) {
					System.out.print("What is the name of the restaurant you would like to add? ");
					restName = scan.nextLine();
	
					if (directory.nameExists(restName)) //MAKE SURE TO CHECK CASE SENSITIVE
					{
						System.out.printf("\nThere is already an entry for " + restName + "\n\n");
					}
					else if (restName == "") //did not enter a name
					{
						continue; //try again
					}
					else { //restaurant is new, name is saved as string
						newName = true;
						System.out.print("\n");
					}
				}
				while(restAddr == "") { //enter address
					System.out.print("What is the address for " + restName + "? ");
					restAddr = scan.nextLine();
					System.out.print("\n");
				}
				while (restLat == 200.0) { //enter latitude
					System.out.print("What is the latitude for " + restName + "? ");
					restLat = Double.parseDouble(scan.nextLine());
					System.out.print("\n");
				}
				while (restLong == 200.0) { //enter longitude
					System.out.print("What is the longitude for " + restName + "? ");
					restLong = Double.parseDouble(scan.nextLine());
					System.out.print("\n");
				}
				
				System.out.print("What does " + restName + " serve? "); //enter entires
				String tempItem = "";
				while (tempItem == "") {//must have a single item
					tempItem = scan.nextLine();
					if (tempItem == "") { //can't be blank!
						System.out.print("\n" + "What does " + restName + " serve? ");
					}
				}
				if (tempItem != "") { //valid entry
					restMenu.add(tempItem);
				}
				
				boolean allItems = false; //all items added?
				while (allItems == false)
				{
					System.out.print("\n\t" + "1) Yes\n" + "\t" + "2) No\nDoes "
									    + restName + " serve anything else? ");
					String tempInput = scan.nextLine();
					System.out.println();
					if (tempInput.equals("1"))
					{ //more items
						System.out.print("What does Cup of Joy serve? ");
						tempItem = scan.nextLine();
						if (tempItem != "") {
							restMenu.add(tempItem);
							continue;
						}
						else {
							continue;
						}
					}
					else if (tempInput.equals("2"))
					{ //no more items
						allItems = true;
						break;
					}
					else { //all other invalid inputs
						System.out.print("\nThat is not a valid option." + "\n" + "\n");
					}
				}		
				
				directory.addRestaurant(restName, restAddr, restLat, restLong, restMenu);
				int loc =  directory.getSize() - 1; //location of restaurant in array
				System.out.print("\nThere is now a new entry for:\n" + restName + ", located " + 
						   directory.getRestaurants().get(loc).getDistanceRounded(userLat, userLong) +
						   " miles away at " + restAddr + "\n" + restName + " serves ");
				
				for (int i=0; i < restMenu.size(); i++) {
					if (i > 0) //more than 1 entry
					{
						System.out.print(", ");
					}
					if (i+1 == restMenu.size()) //last entry in array
					{
						System.out.print("and "); //add and before last item
					}
					System.out.print(restMenu.get(i));
				}
				System.out.println(".");
				
			}
			else if (option.equals("5")) //Remove a restaurant
			{
				if (directory.getSize() == 0) //checking for empty calendar
					System.out.println("There are no restaurants to remove\n");
				else
				{
					boolean validChoice = false;
					while (!validChoice) //loop until valid user is chosen
					{
						String result = "";
						for (int i=0; i < directory.getRestaurants().size(); i++) {
							result += "\t" + (i+1) + ")" + directory.getRestaurants().get(i).getName() + "\n";
						}
						System.out.print(result);
						System.out.print("Which restaurant would you like to remove? ");
						String choiceStr = scan.nextLine(); //string with choice number
						try //user enters a number for the restaurant
						{
							int choice = Integer.parseInt(choiceStr);
							if (choice > 0 && choice <= directory.getRestaurants().size()) //valid choice
							{
								validChoice = true;
								System.out.print("\n" + directory.getRestaurants().get(choice-1).getName() + 
										         " is now removed. \n");
								directory.getRestaurants().remove(choice-1);
							}
							else
								System.out.println("Invalid option\n"); //out of bounds
						}
						catch (NumberFormatException nfe) //must enter a number
						{
							System.out.println("Invalid option\n");
						}
					}
				}
			}
			else if (option.equals("6")) //Sort restaurants
			{
				if (directory.getSize() == 0) //no restaurants exist
					System.out.println("There are no restaurants to remove.\n");
				else
				{
					boolean validChoice = false; //make sure choice is valid
					while (!validChoice) //loop until valid sort is chosen
					{ //all sort methods below:
						System.out.println("1) A to Z");
						System.out.println("2) Z to A");
						System.out.println("3) Closest to farthest");
						System.out.println("4) Farthest to closest");
						System.out.print("How would you like to sort by? ");
						String sortType = scan.nextLine(); //choosing the sort order
						System.out.println();
						
						//use Collections.sort() with various fields. Uses MergeSort.
						if (sortType.equals("1")) { //A-Z
							Collections.sort(directory.getRestaurants(), byName());
							System.out.println("Your restaurants are now sorted from A to Z.");
							validChoice = true;
						}
						else if (sortType.equals("2")) { //Z-A
							Collections.sort(directory.getRestaurants(), Collections.reverseOrder(byName()));
							System.out.println("Your restaurants are now sorted from Z to A.");
							validChoice = true;
						}
						else if (sortType.equals("3")) { //Close-Far
						    Collections.sort(directory.getRestaurants(), byDist(userLat, userLong));
							System.out.println("Your restaurants are now sorted from closest to farthest.");
							validChoice = true;
						}	
						else if (sortType.equals("4")) { //Far-Close
							Collections.sort(directory.getRestaurants(), Collections.reverseOrder(byDist(userLat, userLong)));
							System.out.println("Your restaurants are now sorted from farthest to closest.");
							validChoice = true;
						}
						else {
							System.out.println("Invalid option\n"); //invalid choice, will ask again
						}											
						//directory.printRestaurants(userLat, userLong); //Print debugging
					}
				}
			}		
			else if (option.equals("7")) //Save and Exit
			{
				boolean finish = false;
				while (!finish) //loop until user chooses valid save option
				{
					System.out.println("\t1) Yes");
					System.out.println("\t2) No");
					System.out.print("Would you like to save the file before exiting? ");
					String saveChoice = scan.nextLine();
					System.out.println();
					
					if (saveChoice.equals("1")) //do save
					{
						try //attempt to save file
						{ //use gson to write to initial text file
							String json = gson.toJson(directory);
							PrintWriter pw = new PrintWriter(inputFile);
							pw.println(json); //prints information
							System.out.print("Your edits have been saved to " + inputFile + ".\n");
							pw.close();
						}
						catch (FileNotFoundException fnfe)
						{ //in-case of saving error
							System.out.println("File could not be saved.\n");
						}
						finish = true;
					}
					else if (saveChoice.equals("2")) //don't save
					{
						System.out.println("File was not saved.");
						finish = true;
					}
					else //invalid choice
						System.out.println("Invalid option\n");	
				}
				System.out.println("Thank you for using my program!");
				repeatMenu = false; //exits the program
			}
			else {
				System.out.println("That is not a valid option.");
				showOptions = false;
			}
			System.out.println(); //extra newline for formatting CLI
		}
		scan.close();
	}
}