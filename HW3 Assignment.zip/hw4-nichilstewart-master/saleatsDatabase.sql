DROP DATABASE IF EXISTS saleats;

CREATE DATABASE saleats;

USE saleats;

CREATE TABLE userinfo (
    email VARCHAR(50) PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(50) NOT NULL
);


CREATE TABLE rest (
    idrest VARCHAR(50) PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    address VARCHAR(100) NOT NULL,
    url VARCHAR(100) NOT NULL,
    img VARCHAR(100) NOT NULL,
    phone VARCHAR(50) NOT NULL,
    cuisine VARCHAR(50) NOT NULL,
    price VARCHAR(50) NOT NULL,
    rating VARCHAR(50) NOT NULL    
);


CREATE TABLE link (
    email VARCHAR(50) NULL,
    idrest VARCHAR(50) NULL,

    FOREIGN KEY fk1(email) REFERENCES userinfo(email),
    FOREIGN KEY fk2(idrest) REFERENCES rest(idrest)
);


