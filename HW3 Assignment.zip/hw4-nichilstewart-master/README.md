# HW4:nichilstewart
### Program instructions:

A mySQL script file is included with file archive. Please run with both user and password values set to "root" as shown below:

"jdbc:mysql://localhost/saleats?user=root&password=root"


Thank you!
nichilst@usc.edu
